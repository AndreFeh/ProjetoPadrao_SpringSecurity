package com.dio.securiticomjwt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecuritiComJwtApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecuritiComJwtApplication.class, args);
	}

}
